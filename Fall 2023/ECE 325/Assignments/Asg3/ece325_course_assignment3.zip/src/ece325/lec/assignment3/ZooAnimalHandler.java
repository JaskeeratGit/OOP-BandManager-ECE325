package ece325.lec.assignment3;

import java.util.ArrayList;

public class ZooAnimalHandler implements DanceTherapist, AnimalHandler {
	private ArrayList<ZooAnimal> animals;
	
	public ZooAnimalHandler(ArrayList<ZooAnimal> animals) {
		
	}


}
