public class AlreadyFedException extends Exception{
	private static final long serialVersionUID = 1L;

	public AlreadyFedException(String message) {
		super(message);
	}
}